$"="\t";
$,="\t";
#perl anagram.pl mots.txt >anagrammes.txt
open( NB04," >nb04.txt");
open( NB05," >nb05.txt");
open( NB06," >nb06.txt");
open( NB07," >nb07.txt");
open( NB08," >nb08.txt");
open( NB09," >nb09.txt");
open( NB10," >nb10.txt");
open( NB11," >nb11.txt");
open( NB12," >nb12.txt");
open( NB13," >nb13.txt");
open( NB14," >nb14.txt");
open( NB15," >nb15.txt");
while(<>){
	chomp;
	if (length($_)<=4){print NB04 "$_\n";}	
	if (length($_)==5){print NB05 "$_\n";}	
	if (length($_)==6){print NB06 "$_\n";}	
	if (length($_)==7){print NB07 "$_\n";}	
	if (length($_)==8){print NB08 "$_\n";}	
	if (length($_)==9){print NB09 "$_\n";}	
	if (length($_)==10){print NB10 "$_\n";}	
	if (length($_)==11){print NB11 "$_\n";}	
	if (length($_)==12){print NB12 "$_\n";}	
	if (length($_)==13){print NB13 "$_\n";}	
	if (length($_)==14){print NB14 "$_\n";}	
	if (length($_)>=15){print NB15 "$_\n";}	
	#else  {print "$_\n";}
}