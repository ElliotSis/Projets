$"="\t";
$,="\t";
#perl anagram.pl mots.txt >anagrammes.txt


while(<>){
	chomp;
	#@F=split("\t");
	#if (length($_) > 8){continue;}
	print "\n$_\t";

	$sortie=`anagram --bindict nb15.bin $_`;
	#$sortie=`anagram --bindict D:/Anagram/words.bin $_`;
	@F=split(/\n/,$sortie);

	#print @F;
	
	foreach $i (@F){
		if (($i !~ /.*\ .*/)&&($i ne $_)){
		print " $i";}
		} 

#~ #print $sortie;
}