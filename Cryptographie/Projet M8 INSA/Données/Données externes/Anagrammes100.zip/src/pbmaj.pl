$"="\t";
$,="\t";
#perl anagram.pl mots.txt >anagrammes.txt


while(<>){
	chomp;
	@F=split("\t");
	#@premmot=split("",$F[0]);
	
	@anag=split(" ",$F[1]);
	$impression= "\n$F[0]\t";
		MOT: foreach ($j=0;$j<@anag;$j++){
			@cibledecoup=split("",$anag[$j]);
			$cible=$anag[$j];
			foreach $i (@cibledecoup){
				if ($F[0] !~ /$i/){
				delete($anag[$j]);next MOT;}
		
		}
		$impression .= "$anag[$j] "; 
		}
		
$impression =~ s/ $//g;
print "$impression";

}